//
//  AppDelegate.swift
//  DemoAppSwift
//
//  Created by Developer on 24.07.2020.
//  Copyright © 2020 Developer. All rights reserved.
//

import UIKit
import AvMessagingSdk

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        return true
    }
}

