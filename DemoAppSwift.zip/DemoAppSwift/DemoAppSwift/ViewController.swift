//
//  ViewController.swift
//  DemoAppSwift
//
//  Created by Developer on 25.07.2020.
//  Copyright © 2020 Developer. All rights reserved.
//

import Foundation
import AvMessagingSdk

class ViewController: UIViewController, UITextFieldDelegate {
    
    var isInitSDK = false
    var isLoggedIn = false
    var integrationID = ""
    var firstName = ""
    var lastName = ""
    var userID = ""
    var jwt = ""
    var isAuthUser = false
    
    @IBOutlet var UserIDLabel: UILabel!
    @IBOutlet var UserIDTextField: UITextField!
    @IBOutlet var JWTLabel: UILabel!
    @IBOutlet var JWTTextField: UITextField!
    @IBOutlet var InitButton: UIButton!
    @IBOutlet var StartButton: UIButton!
    @IBOutlet var interactionIDField: UITextField!
    @IBOutlet var firstNameTextField: UITextField!
    @IBOutlet var lastNameTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        interactionIDField.delegate = self
        firstNameTextField.delegate = self
        lastNameTextField.delegate = self
        
        InitButton.isHidden = true
        StartButton.isHidden = true
        JWTTextField.delegate = self
        UserIDTextField.delegate = self
    }
   
    
    @IBAction func onButton(_ sender: Any) {
        self.logout()
    }
    
    @IBAction func initButtonPressed(_ sender: UIButton) {
        initSDK()
    }
    
    @IBAction func AuthUserSwitch(_ sender: Any) {
        let switchAuthUser = sender as! UISwitch
        isAuthUser = switchAuthUser.isOn
        UserIDLabel.isHidden = !switchAuthUser.isOn
        UserIDTextField.isHidden = !switchAuthUser.isOn
        JWTLabel.isHidden = !switchAuthUser.isOn
        JWTTextField.isHidden = !switchAuthUser.isOn
    }
    
    
    @IBAction func handleInteractionID(_ sender: UITextField) {
        let newValue : String! = sender.text
        if (!newValue.elementsEqual(integrationID)) {
            InitButton.isEnabled = true
            integrationID = newValue
            InitButton.isHidden = false
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func handleFirstName(_ sender: UITextField) {
        firstName = sender.text!
    }
    
    @IBAction func handleLastName(_ sender: UITextField) {
        lastName = sender.text!
    }
    
    @IBAction func handleUserID(_ sender: UITextField) {
        userID = sender.text!
    }
    
    @IBAction func handleJWT(_ sender: UITextField) {
        jwt = sender.text!
    }
    
    private func initSDK() {
        let settings = AVASettings(integrationId: integrationID)
        settings.conversationAccentColor = UIColor(red: 39.0/255, green: 149.0/255, blue: 249.0/255, alpha: 1)
        AvMessagingSdk.initWith(settings) { (error: Error?, userInfo: [AnyHashable : Any]?) in
            if (error == nil) {
                self.isInitSDK = true
                self.StartButton.isEnabled = true
                self.StartButton.isHidden = false
            }else{
                self.isInitSDK = false
            }
                    
        }

    }
    
    private func logout() {
        AvMessagingSdk.logout(){ ( error:Error? , userInfo:[AnyHashable : Any]?) in
            if (error == nil) {
                // Your code after login is complete
                self.login()
            }else{
                // Something went wrong during login. Your JWT might be invalid
                self.login()
            }
            
        }
    }
    
    private func login() {
        if(self.userID != "" && isAuthUser) {
            AvMessagingSdk.login(self.userID, jwt: self.jwt)
            { ( error:Error? , userInfo:[AnyHashable : Any]?) in
                if (error == nil) {
                    // Your code after login is complete
                    AvMessagingSdk.show()
                }else{
                    // Something went wrong during login. Your JWT might be invalid
                }
                
            }
        } else {
            AvMessagingSdk.show ()
            
        }
    }
    
    private func setExtendedParameters() {
        AvMessagingSdk.setUserFirstName(self.firstName, lastName: self.lastName)
                AVAUser.current()?.addProperties(["premiumUser": true,
                                                  "numberOfPurchases": 20,
                                                  "itemsInCart": 3,
                                                  "couponCode": "PREM_USR"])
    }
    
    
}
